package com.sangji0729.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository("testDAO")
public class TestDAO extends AbstractDAO {
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> categoryList() {
		return selectList("test.categoryList");
	}

	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> productList() {
		return selectList("test.productList");
	}
}
