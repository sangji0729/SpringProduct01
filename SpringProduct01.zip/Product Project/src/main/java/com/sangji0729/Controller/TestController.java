package com.sangji0729.Controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sangji0729.service.TestService;
import com.sangji0729.service.TestServiceImpl;

@Controller
public class TestController {
	Logger log = Logger.getLogger(this.getClass());
	@Resource(name = "testService")
	private TestServiceImpl testService;

	@RequestMapping(value = "/main.do")
	public ModelAndView main() throws Exception {
		ModelAndView mv = new ModelAndView("main");
		List<Map<String, Object>> categoryList = testService.categoryList();
		List<Map<String, Object>> productList = testService.productList();
		mv.addObject("list", categoryList);
		mv.addObject("productList", productList);
		//System.out.println(categoryList);
		
		return mv;
	}
}